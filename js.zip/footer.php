	<!-- start footer Area -->
	<footer class="footer-area">
		<div class="container">
			<div class="row">
				<div class="col-lg-4  col-md-6 col-sm-6">
					<div class="single-footer-widget">
						<h6>Tentang Kami</h6>
						<p>
							Kelompok 1 Kom B<br>
							Brillian Jonathan Tantri&emsp;&nbsp;&nbsp;(191402119)<br>
							Dwiki Affandi&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp; (191402011)<br>
							Margaretha G. A. Naibaho (191402014)<br>
							Michael &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;(191402059)<br>
							Milpa Wahyuni Siregar &emsp;&nbsp;&nbsp;(191402005)
						</p>
					</div>
				</div>
				<div class="col-lg-6  col-md-6 col-sm-6">
					<div class="single-footer-widget mail-chimp">
						<h6 class="mb-20">Instragram Feed</h6>
						<ul class="instafeed d-flex flex-wrap">
							<li><img src="img/i1.jpg" alt=""></li>
							<li><img src="img/i2.jpg" alt=""></li>
							<li><img src="img/i3.jpg" alt=""></li>
							<li><img src="img/i4.jpg" alt=""></li>
							<li><img src="img/i5.jpg" alt=""></li>
							<li><img src="img/i6.jpg" alt=""></li>
							<li><img src="img/i7.jpg" alt=""></li>
							<li><img src="img/i8.jpg" alt=""></li>
						</ul>
					</div>
				</div>
				<div class="col-lg-2 col-md-6 col-sm-6">
					<div class="single-footer-widget">
						<h6>Follow Us</h6>
						<p>Let us be social</p>
						<div class="footer-social align-items-center">
							<a href="https://www.instagram.com/brillianjonathan/?hl=id"><i class="fa fa-instagram"></i></a>Brillian<br>
							<a href="https://www.instagram.com/dwiki_affandi/?hl=id"><i class="fa fa-instagram"></i></a>Dwiki<br>
							<a href="https://www.instagram.com/margarethanaibaho/?hl=id"><i class="fa fa-instagram"></i></a>Margaretha<br>
							<a href="https://www.instagram.com/mikel_kel21/?hl=id"><i class="fa fa-instagram"></i></a>Michael<br>
							<a href="https://www.instagram.com/milpa_wahyuni/?hl=id"><i class="fa fa-instagram"></i></a>Milpa
						</div>
					</div>
				</div>
			</div>
			<div class="footer-bottom d-flex justify-content-center align-items-center flex-wrap">
				<p class="footer-text m-0"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This Online Shop is made by <u>Kelompok 1 Kom B</u>
<br><br></p>
			</div>
		</div>
	</footer>
	<!-- End footer Area -->